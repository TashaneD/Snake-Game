// place your code starting on line 2 above the export statement below

export default {};
// export default IQuacker;
